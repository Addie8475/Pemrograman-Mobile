package com.example.a2048

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.os.Bundle
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.GridLayout
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.view.GestureDetectorCompat
import kotlin.math.abs
import kotlin.random.Random

class GameActivity : AppCompatActivity() {

    private lateinit var gameGrid: GridLayout
    private lateinit var highScoreTextView: TextView
    private var board = Array(4) { IntArray(4) }
    private lateinit var tiles: Array<Array<TextView?>>
    private var score = 0
    private var highScore = 0

    private lateinit var gestureDetector: GestureDetectorCompat
    private var isAnimating = false

    // Deklarasikan View untuk Game Over dan Tombol Menu Utama
    private lateinit var gameOverGroup: ConstraintLayout
    private lateinit var menuButton: Button // Pindahkan deklarasi ke sini

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_game)

        // 1. Inisialisasi semua View terlebih dahulu
        gameGrid = findViewById(R.id.gameGrid)
        highScoreTextView = findViewById(R.id.highScoreValueTextView)
        menuButton = findViewById(R.id.menuButton) // Inisialisasi properti kelas
        gameOverGroup = findViewById(R.id.gameOverGroup)
        val playAgainButton = findViewById<Button>(R.id.playAgainButton)
        val menuGameOverButton = findViewById<Button>(R.id.menuGameOverButton)


        // 2. Atur semua listener
        menuButton.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Back to Menu")
                .setMessage("Are you sure? Your current game will be saved.")
                .setPositiveButton("Yes") { _, _ ->
                    saveGame()
                    finish()
                }
                .setNegativeButton("No", null)
                .show()
        }

        playAgainButton.setOnClickListener {
            gameOverGroup.visibility = View.GONE
            clearSaveState()
            setupBoard()
        }

        menuGameOverButton.setOnClickListener {
            finish()
        }


        // 3. Atur logika utama (start/continue)
        val isContinue = intent.getBooleanExtra("CONTINUE_GAME", false)
        if (isContinue) {
            setupBoard(initializeWithNumbers = false)
            loadGame()
        } else {
            clearSaveState()
            setupBoard()
        }

        gestureDetector = GestureDetectorCompat(this, MyGestureListener())
    }

    // --- FUNGSI-FUNGSI LAINNYA ---

    private fun saveGame() {
        val prefs = getSharedPreferences("GameState", MODE_PRIVATE)
        val editor = prefs.edit()

        editor.putInt("currentScore", score)
        // High score sudah disimpan setiap kali di-update, tapi simpan lagi untuk konsistensi
        editor.putInt("highScore", highScore)

        for (i in 0 until 4) {
            for (j in 0 until 4) {
                editor.putInt("board_${i}_${j}", board[i][j])
            }
        }
        editor.putBoolean("isGameSaved", true)
        editor.apply()
    }

    private fun loadGame() {
        val prefs = getSharedPreferences("GameState", MODE_PRIVATE)
        if (!prefs.getBoolean("isGameSaved", false)) {
            setupBoard()
            return
        }

        score = prefs.getInt("currentScore", 0)
        highScore = prefs.getInt("highScore", 0)

        for (i in 0 until 4) {
            for (j in 0 until 4) {
                board[i][j] = prefs.getInt("board_${i}_${j}", 0)
            }
        }
        updateBoardUI()
        updateScore(0)
    }

    private fun clearSaveState() {
        val prefs = getSharedPreferences("GameState", MODE_PRIVATE)
        val editor = prefs.edit()
        editor.putBoolean("isGameSaved", false)
        // Hapus hanya data board dan skor saat ini, JANGAN HAPUS HIGH SCORE
        for (i in 0 until 4) {
            for (j in 0 until 4) {
                editor.remove("board_${i}_${j}")
            }
        }
        editor.remove("currentScore")
        editor.apply()
    }

    override fun onTouchEvent(event: MotionEvent?): Boolean {
        if (!isAnimating && event != null) {
            gestureDetector.onTouchEvent(event)
        }
        return super.onTouchEvent(event)
    }

    private fun setupBoard(initializeWithNumbers: Boolean = true) {
        // Aktifkan kembali tombol menu saat game dimulai
        menuButton.isEnabled = true
        menuButton.alpha = 1.0f // Kembalikan ke opasitas penuh

        board = Array(4) { IntArray(4) { 0 } }
        tiles = Array(4) { arrayOfNulls<TextView>(4) }
        score = 0

        // Muat high score yang ada dari SharedPreferences
        val prefs = getSharedPreferences("GameState", MODE_PRIVATE)
        highScore = prefs.getInt("highScore", 0)
        updateScore(0)

        gameGrid.removeAllViews()

        for (i in 0 until 4) {
            for (j in 0 until 4) {
                val tile = layoutInflater.inflate(R.layout.tile_layout, gameGrid, false) as TextView
                val params = GridLayout.LayoutParams(
                    GridLayout.spec(i, 1f),
                    GridLayout.spec(j, 1f)
                )
                params.width = 0
                params.height = 0
                params.setMargins(12, 12, 12, 12)
                tile.layoutParams = params
                gameGrid.addView(tile)
                tiles[i][j] = tile
            }
        }

        if (initializeWithNumbers) {
            addNewNumber(isInitial = true)
            addNewNumber(isInitial = true)
        }
        updateBoardUI()
    }

    private fun updateBoardUI() {
        for (i in 0 until 4) {
            for (j in 0 until 4) {
                val value = board[i][j]
                val tile = tiles[i][j]
                if (tile != null) {
                    if (value == 0) {
                        tile.text = ""
                        tile.setBackgroundColor(getColor(R.color.tile_empty))
                    } else {
                        tile.text = value.toString()
                        tile.setBackgroundColor(getTileColor(value))
                    }
                }
            }
        }
    }

    // --- FUNGSI INI TELAH DIPERBARUI ---
    private fun addNewNumber(isInitial: Boolean = false) {
        val emptyCells = mutableListOf<Pair<Int, Int>>()
        var maxTile = 0 // Variabel untuk menyimpan nilai ubin tertinggi

        // Cari sel kosong dan ubin dengan nilai tertinggi secara bersamaan
        for (i in 0 until 4) {
            for (j in 0 until 4) {
                if (board[i][j] == 0) {
                    emptyCells.add(Pair(i, j))
                }
                if (board[i][j] > maxTile) {
                    maxTile = board[i][j] // Update ubin tertinggi
                }
            }
        }

        if (emptyCells.isNotEmpty()) {
            val (row, col) = emptyCells.random()

            // Tentukan angka baru berdasarkan ubin tertinggi yang ada di papan
            val newNumber = when {
                maxTile >= 1024 -> if (Random.nextBoolean()) 32 else 32
                maxTile >= 512  -> if (Random.nextBoolean()) 16 else 32
                maxTile >= 256  -> if (Random.nextBoolean()) 8 else 16
                maxTile >= 128  -> if (Random.nextBoolean()) 4 else 8
                else            -> if (Random.nextInt(10) < 9) 2 else 4   // Level 1 (Default): Munculkan 2 (90%) atau 4 (10%)
            }

            board[row][col] = newNumber
            updateBoardUI()

            if (!isInitial) {
                val newTile = tiles[row][col]
                newTile?.apply {
                    scaleX = 0f
                    scaleY = 0f
                    animate().scaleX(1f).scaleY(1f).setDuration(200).start()
                }
            }
        }
    }

    private fun getTileColor(value: Int): Int {
        return when (value) {
            2 -> getColor(R.color.tile_2)
            4 -> getColor(R.color.tile_4)
            8 -> getColor(R.color.tile_8)
            16 -> getColor(R.color.tile_16)
            32 -> getColor(R.color.tile_32)
            64 -> getColor(R.color.tile_64)
            128 -> getColor(R.color.tile_128)
            256 -> getColor(R.color.tile_256)
            512 -> getColor(R.color.tile_512)
            1024 -> getColor(R.color.tile_1024)
            2048 -> getColor(R.color.tile_2048)
            else -> getColor(R.color.tile_super)
        }
    }

    private fun updateScore(points: Int) {
        score += points
        if (score > highScore) {
            highScore = score
            // Langsung simpan high score yang baru ke SharedPreferences
            val prefs = getSharedPreferences("GameState", MODE_PRIVATE)
            val editor = prefs.edit()
            editor.putInt("highScore", highScore)
            editor.apply()
        }
        highScoreTextView.text = String.format("%04d", highScore)
    }

    private fun checkGameOver() {
        for (i in 0 until 4) {
            for (j in 0 until 4) {
                if (board[i][j] == 0) return
            }
        }
        for (i in 0 until 4) {
            for (j in 0 until 3) {
                if (board[i][j] == board[i][j + 1]) return
            }
        }
        for (j in 0 until 4) {
            for (i in 0 until 3) {
                if (board[i][j] == board[i + 1][j]) return
            }
        }

        // Jika game over, tampilkan layar dan nonaktifkan tombol menu utama
        gameOverGroup.visibility = View.VISIBLE
        menuButton.isEnabled = false
        menuButton.alpha = 0.5f // Redupkan tombol untuk umpan balik visual
    }

    private inner class MyGestureListener : GestureDetector.SimpleOnGestureListener() {
        private val swipeThreshold = 50
        private val swipeVelocityThreshold = 50

        override fun onFling(e1: MotionEvent?, e2: MotionEvent, velocityX: Float, velocityY: Float): Boolean {
            if (e1 == null) return false
            val diffX = e2.x - e1.x
            val diffY = e2.y - e1.y

            if (abs(diffX) > abs(diffY)) {
                if (abs(diffX) > swipeThreshold && abs(velocityX) > swipeVelocityThreshold) {
                    if (diffX > 0) move(Direction.RIGHT) else move(Direction.LEFT)
                    return true
                }
            } else {
                if (abs(diffY) > swipeThreshold && abs(velocityY) > swipeVelocityThreshold) {
                    if (diffY > 0) move(Direction.DOWN) else move(Direction.UP)
                    return true
                }
            }
            return false
        }
    }

    enum class Direction { UP, DOWN, LEFT, RIGHT }

    private fun move(direction: Direction) {
        if (isAnimating) return
        isAnimating = true

        val animations = mutableListOf<Animator>()
        val newBoard = Array(4) { IntArray(4) { 0 } }
        var scoreFromThisMove = 0

        for (i in 0 until 4) {
            val line = mutableListOf<Pair<Int, Int>>()
            for (j in 0 until 4) {
                val value = when (direction) {
                    Direction.LEFT -> board[i][j]
                    Direction.RIGHT -> board[i][3 - j]
                    Direction.UP -> board[j][i]
                    Direction.DOWN -> board[3 - j][i]
                }
                if (value != 0) {
                    line.add(Pair(j, value))
                }
            }

            val mergedLine = mutableListOf<Pair<Int, Int>>()
            var k = 0
            while (k < line.size) {
                if (k + 1 < line.size && line[k].second == line[k + 1].second) {
                    val mergedValue = line[k].second * 2
                    scoreFromThisMove += mergedValue
                    mergedLine.add(Pair(line[k].first, mergedValue))

                    val fromPos = getOriginalPosition(direction, i, line[k + 1].first)
                    val toPos = getOriginalPosition(direction, i, line[k].first)
                    val tileToAnimate = tiles[fromPos.first][fromPos.second]
                    val targetTile = tiles[toPos.first][toPos.second]
                    if (tileToAnimate != null && targetTile != null) {
                        val transX = ObjectAnimator.ofFloat(tileToAnimate, "translationX", targetTile.x - tileToAnimate.x)
                        val transY = ObjectAnimator.ofFloat(tileToAnimate, "translationY", targetTile.y - tileToAnimate.y)
                        animations.add(AnimatorSet().apply { playTogether(transX, transY) })
                    }
                    k += 2
                } else {
                    mergedLine.add(line[k])
                    k += 1
                }
            }

            for (newIndex in mergedLine.indices) {
                val oldIndex = mergedLine[newIndex].first
                val value = mergedLine[newIndex].second

                val fromPos = getOriginalPosition(direction, i, oldIndex)
                val toPos = getOriginalPosition(direction, i, newIndex)

                newBoard[toPos.first][toPos.second] = value

                if (fromPos != toPos) {
                    val tileToAnimate = tiles[fromPos.first][fromPos.second]
                    val targetTile = tiles[toPos.first][toPos.second]
                    val isAlreadyAnimating = animations.any {
                        val animSet = it as AnimatorSet
                        animSet.childAnimations.any { anim -> (anim as ObjectAnimator).target == tileToAnimate }
                    }

                    if (!isAlreadyAnimating && tileToAnimate != null && targetTile != null) {
                        val transX = ObjectAnimator.ofFloat(tileToAnimate, "translationX", targetTile.x - tileToAnimate.x)
                        val transY = ObjectAnimator.ofFloat(tileToAnimate, "translationY", targetTile.y - tileToAnimate.y)
                        animations.add(AnimatorSet().apply { playTogether(transX, transY) })
                    }
                }
            }
        }

        val moved = !board.contentDeepEquals(newBoard)

        if (moved) {
            updateScore(scoreFromThisMove)
            board = newBoard

            val animatorSet = AnimatorSet()
            animatorSet.playTogether(animations)
            animatorSet.duration = 150

            animatorSet.addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    for (row in 0 until 4) {
                        for (col in 0 until 4) {
                            tiles[row][col]?.translationX = 0f
                            tiles[row][col]?.translationY = 0f
                        }
                    }
                    updateBoardUI()
                    addNewNumber()
                    checkGameOver()
                    isAnimating = false
                }
            })
            animatorSet.start()
        } else {
            isAnimating = false
        }
    }

    private fun getOriginalPosition(direction: Direction, lineIndex: Int, cellIndex: Int): Pair<Int, Int> {
        return when (direction) {
            Direction.LEFT -> Pair(lineIndex, cellIndex)
            Direction.RIGHT -> Pair(lineIndex, 3 - cellIndex)
            Direction.UP -> Pair(cellIndex, lineIndex)
            Direction.DOWN -> Pair(3 - cellIndex, lineIndex)
        }
    }
}
