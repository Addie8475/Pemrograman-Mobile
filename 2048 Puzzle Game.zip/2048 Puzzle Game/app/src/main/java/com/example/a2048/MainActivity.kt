package com.example.a2048

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatButton

class MainActivity : AppCompatActivity() {

    private lateinit var continueButton: AppCompatButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val startButton = findViewById<AppCompatButton>(R.id.startButton)
        continueButton = findViewById(R.id.continueButton) // Inisialisasi di sini
        val instructionsButton = findViewById<AppCompatButton>(R.id.instructionsButton)
        val quitButton = findViewById<AppCompatButton>(R.id.quitButton)

        startButton.setOnClickListener {
            val intent = Intent(this, GameActivity::class.java)
            // Kirim extra untuk menandakan ini BUKAN game lanjutan
            intent.putExtra("CONTINUE_GAME", false)
            startActivity(intent)
        }

        continueButton.setOnClickListener {
            val intent = Intent(this, GameActivity::class.java)
            // Kirim extra untuk menandakan INI ADALAH game lanjutan
            intent.putExtra("CONTINUE_GAME", true)
            startActivity(intent)
        }

        instructionsButton.setOnClickListener {
            startActivity(Intent(this, InstructionsActivity::class.java))
        }

        quitButton.setOnClickListener {
            finish()
        }
    }

    override fun onResume() {
        super.onResume()
        // Cek status game setiap kali MainActivity ditampilkan
        checkSavedGame()
    }

    private fun checkSavedGame() {
        val prefs = getSharedPreferences("GameState", MODE_PRIVATE)
        val isGameSaved = prefs.getBoolean("isGameSaved", false)

        // Tampilkan atau sembunyikan tombol "Continue"
        if (isGameSaved) {
            continueButton.visibility = View.VISIBLE
        } else {
            continueButton.visibility = View.GONE
        }
    }
}
