package com.example.a2048

import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity    class InstructionsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Menghubungkan file layout activity_instructions.xml ke activity ini
        setContentView(R.layout.activity_instructions)

        // Mengambil referensi tombol 'Back' dari layout
        val backButton = findViewById<Button>(R.id.backButton)

        // Menambahkan listener klik pada tombol 'Back'
        backButton.setOnClickListener {
            // Menutup activity ini dan kembali ke activity sebelumnya (MainActivity)
            finish()
        }
    }
}
